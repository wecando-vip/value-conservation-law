[Console]::OutputEncoding = [Text.Encoding]::UTF8
$base = 'D:\00 财情双生智库\AI财情双生智库\财情倍增的价值守恒定律'
Write-Host '=== 根目录条目 ==='
Get-ChildItem $base | Select-Object Mode,Name | Format-Table -AutoSize
$zh = Join-Path $base 'zh'
Write-Host '=== zh 目录 ==='
if (Test-Path $zh) {
    $z = Get-ChildItem $zh -Filter *.html
    Write-Host ('zh 下 html 数量: ' + $z.Count)
    $z | Select-Object -First 30 Name | Format-Table -AutoSize
} else {
    Write-Host 'zh 目录不存在'
}
Write-Host '=== 全盘搜 财务管理_价值守恒论证.html ==='
Get-ChildItem $base -Recurse -Filter '财务管理_价值守恒论证.html' -ErrorAction SilentlyContinue | Select-Object FullName | Format-List
Write-Host '=== DONE ==='
