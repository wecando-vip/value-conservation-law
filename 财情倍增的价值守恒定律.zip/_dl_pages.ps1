$ErrorActionPreference = 'Stop'
$dest = 'D:\00 财情双生智库\AI财情双生智库\财情倍增的价值守恒定律\zh'
$tmpZip = Join-Path $env:TEMP 'cw_dl_20260826.zip'
$tmpDir = Join-Path $env:TEMP 'cw_dl_20260826_x'
$url = 'https://www.coze.cn/s/H6y3eaqfBKQ/'
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
Write-Host '--- download ---'
Invoke-WebRequest -Uri $url -OutFile $tmpZip -UseBasicParsing
Write-Host ('downloaded bytes: ' + (Get-Item $tmpZip).Length)
if (Test-Path $tmpDir) { Remove-Item $tmpDir -Recurse -Force }
Expand-Archive -Path $tmpZip -DestinationPath $tmpDir -Force
Write-Host '--- unzip ok ---'
if (-not (Test-Path $dest)) { New-Item -ItemType Directory -Path $dest -Force | Out-Null }
$copied = @(); $skipped = @()
Get-ChildItem $tmpDir -Filter *.html | ForEach-Object {
    $target = Join-Path $dest $_.Name
    if (Test-Path $target) { $skipped += $_.Name } else { Copy-Item $_.FullName -Destination $target; $copied += $_.Name }
}
Remove-Item $tmpZip -Force -ErrorAction SilentlyContinue
Remove-Item $tmpDir -Recurse -Force -ErrorAction SilentlyContinue
Write-Host ("=== COPIED " + $copied.Count + " ===")
$copied | ForEach-Object { Write-Host $_ }
Write-Host ("=== SKIPPED " + $skipped.Count + " ===")
$skipped | ForEach-Object { Write-Host $_ }
Write-Host '=== DONE ==='
