# 项目长期记忆:财情倍增的价值守恒定律

## 项目背景
- 财情双生智库(Econ-Sentiment Twin Think Tank)开源理论项目,账号 wecando-vip。
- 核心理论:价值守恒定律 `Y = E × S × T`(经济×社会×时间价值)+ 7 层深度方法论(信息→物质→行为→躯体→觉知→潜意识→心智层)+ 财情双生理念。
- 已发布 GitHub:https://github.com/wecando-vip/value-conservation-law(公开,CC BY-NC 4.0)。

## 项目约定
- 文档形式:纯 HTML/CSS/JS 单文件、零依赖、中英双语(index.html / index.en.html),structure.json 为结构化数据。
- **网页设计体系(重要)**:系列应用页 01-06 为深色夜蓝版;自 07 起(13/14 为基准)为**浅色纸感版**(米白底 #faf9f6、白卡、深蓝 #16324f、金 #a67c2e、grid 布局 228px 左侧 toc、progress 顶条、toTop 按钮)。**新页面必须读取最近一期(如 14)的实际 CSS 逐字复用**,不能凭印象。
- **网页字体(重要约定):默认使用阿里巴巴普惠体(免费商用)**。CDN:https://unpkg.com/common_word_font@1.0.20/alibaba-puhuiti/stylesheetforall.css ,font-family 首项 `"Alibaba PuHuiTi 2.0"`,兜底 `"PingFang SC","Microsoft YaHei",sans-serif`。此偏好同时写入用户级 ~/.workbuddy/MEMORY.md,以后所有网页生成均默认采用。
- 许可:内容类用 **CC BY-NC 4.0**(署名-非商业性使用 4.0 国际,禁止商业用途);若写代码需另用 MIT(内容 CC BY-NC + 代码 MIT 双协议)。
- 本地 git 无全局配置,仓库级配置为 wecando-vip / wecandovip@gmail.com;发布用 PAT,用完撤销。
- **GitHub 发布经验(重要)**:本机无法直连 GitHub,需本地代理(常见端口 7892);公开仓库 ls-remote 无需认证,不能据此判断凭证有效;GCM 在无交互环境会弹窗挂起,须用 `GIT_ASKPASS` + `git -c credential.helper=` 绕过,且 askpass 脚本要用 Windows 真实路径(Git Bash 的 /tmp git.exe 不识别);凭证/代理用后即撤。
- **文库结构**:15 主题 × 四语(zh/en/es/fr 各 15)= 60 页面,library.html 为总索引,README 系列表同步维护;新增语言复用 build_es.py/build_fr.py + *_parts 模式。

## 技能资产
- COZE「财情17Skill」已蒸馏为 WorkBuddy 用户级技能:`~/.workbuddy/skills/财情17Skill/`(整合包,17 技能路由 + 铸卡资源,技能名 `财情17Skill`)。
- 备份源:`D:/00 财情双生智库/COZESkill备份/财情17Skill COZE20260815_085113.tar.gz`。
- 铸卡依赖 Node + Playwright;模板 7 套(long/infograph/poster/sketchnote/comic/whiteboard/big)。
